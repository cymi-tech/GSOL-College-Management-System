from django.contrib import admin
from django.urls import path
from college import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/login/", views.LoginView.as_view(), name="login"),
    path("accounts/logout/", views.LogoutView.as_view(), name="logout"),
    path("", views.dashboard, name="dashboard"),
    path("health/", views.health, name="health"),
    path("workflow/<int:pk>/decision/", views.workflow_decision, name="workflow-decision"),
]
