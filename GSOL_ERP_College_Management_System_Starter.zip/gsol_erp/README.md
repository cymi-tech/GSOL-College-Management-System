# GSOL ERP — College Management System starter

A production-oriented Django/PostgreSQL foundation for the eight GSOL lifecycle stages and wider college ERP modules. This is a **starter implementation**, not a fully audited production release. Review the deployment/security checklist before real student data is loaded.

## Included in this starter

- Custom user with institutional role field
- Departments, programs, applicants, students, semesters, courses and course registration
- Attendance, assignments, submissions, rubric data and assessment-result states
- Practical ministry plans, hour logs and mentor review fields
- Fee invoices and library-loan clearance records
- Graduation applications, credit-audit fields, graduation documents with verification tokens, and alumni profiles
- Explicit workflow approval gates with server-side capability checks, transactional decisions, and audit events
- Login/logout, role-aware dashboard, Django Admin, health endpoint
- Moodle course/assignment ID fields to support integration mapping
- PostgreSQL Docker Compose service and environment-based settings

## 1. Requirements

- Python 3.11+ (recommended)
- Docker Desktop / Docker Engine with Compose, or a separately installed PostgreSQL 15+
- Git (optional)

## 2. Start locally

### Windows PowerShell

```powershell
cd gsol_erp
py -3.12 -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
docker compose up -d db
python manage.py makemigrations college
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

### macOS / Linux

```bash
cd gsol_erp
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
docker compose up -d db
python manage.py makemigrations college
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/ and sign in. Admin is at http://127.0.0.1:8000/admin/. Health check: http://127.0.0.1:8000/health/.

The `.env.example` uses local-only development credentials. Do not reuse them in production. If PostgreSQL is not available, settings fall back to SQLite for a quick code smoke test; PostgreSQL is recommended for all serious testing and production.

## 3. Initial setup

1. Create your superuser.
2. Sign into `/admin/`.
3. Create Departments, then Programs, Semesters, and Courses.
4. Create users and assign the least-privilege role from the GSOL role list.
5. Add Applicants and Students.
6. Create approval gates for eligible objects; workflow decisions are available to users with `workflow.decide`.
7. Review `Audit Events` for login and state-changing request events.

A superuser has all Django Admin permissions. The custom role capability checks apply to service actions and workflow decisions. Before launch, also configure Django Groups/ModelPermissions for every admin view and add object-level restrictions so users only access their assigned students/courses.

## 4. Workflow design mapped from the GSOL diagrams

| GSOL stage | Primary entities | Gate / control |
|---|---|---|
| 1. Admissions | Applicant, Program | Document verification and eligibility decision |
| 2. Enrollment | Applicant, Student, FeeInvoice | Offer accepted, payment recorded, unique student ID |
| 3. Registration | Student, Semester, Course, CourseRegistration | Prerequisites and credit limit checks (expand before production) |
| 4. ODL delivery | Course, Assignment, Submission, AttendanceRecord | Moodle or print mode; completion status |
| 5. Assessment | AssessmentResult | Marking → moderation → approval → publication |
| 6. Practical ministry | MinistryPlan, MinistryLog | Plan approval, mentor evaluation, coordinator review |
| 7. Clearance | GraduationApplication, FeeInvoice, LibraryLoan, WorkflowGate | Credit audit, comprehensive exam, exit interview, dues, registrar/council approvals, list lock |
| 8. Graduation & alumni | GraduationDocument, AlumniProfile | Certificate/transcript issuance and verification token |

Dashed boxes are represented by `WorkflowGate`. Each decision is performed in a database transaction and records who decided, when, and why. The service layer is the correct place to add stage-specific validation. Never rely on hiding a button in the UI as an authorization control.

## 5. Moodle integration plan

This starter stores `Course.moodle_course_id` and `Assignment.moodle_assignment_id`; it does **not** yet call Moodle APIs. Next implementation slice should add:
- A Moodle web-service token stored in a secret manager/environment variable (never in source control)
- A dedicated integration service for course lookup, enrolment, assignment sync and grade sync
- Idempotent sync jobs and retry/error records
- A restricted Moodle service account and a staging Moodle instance
- Mapping of Moodle user IDs to GSOL users, with consent and data-minimization controls

Use Moodle's official web services and verify the API functions enabled by the institution's Moodle administrator before implementing calls.

## 6. Roles

Roles are declared in `college/roles.py`: Super Admin, College Admin, Registrar, Admissions Officer, Academic Coordinator, Faculty, Examiner, Moderator, Ministry Mentor, Ministry Coordinator, Accountant, Librarian, HR Manager, Student, Parent/Guardian, and Alumni Officer.

Capabilities are intentionally explicit. Extend them as workflows are implemented. For production, combine capability checks with Django model permissions and object-level checks.

## 7. Production hardening checklist

Before real use:
- Replace `DJANGO_SECRET_KEY`; set `DJANGO_DEBUG=False`; set exact `DJANGO_ALLOWED_HOSTS`
- Use managed PostgreSQL/private networking, TLS, encrypted backups and a tested restore procedure
- Enforce HTTPS, secure cookies, HSTS and a reverse proxy; configure trusted origins
- Configure email/SMS delivery, password reset, MFA for privileged accounts and login rate limits
- Add object-level access checks, approval separation-of-duties, and prevent self-approval where required
- Validate uploads, scan uploaded files, set size limits, and use private object storage
- Add retention/deletion policies, privacy notices, consent, and applicable Indian data-protection and education-record requirements
- Add automated tests, dependency scanning, monitoring, error reporting, and incident response
- Test all approval paths, race conditions, backups, and concurrent grade publication
- Have a security professional review before production

## 8. Important limitations in this starter

This repository establishes the schema and first working web surface, but it is not the entire finished ERP. It does not yet include complete payment-gateway reconciliation, payroll accounting, full library inventory, transport/hostel operations, automated credit/prerequisite calculations, Moodle API sync, PDF certificate generation, email notifications, or a public verification page. Those should be delivered as tested increments rather than represented as finished features.
