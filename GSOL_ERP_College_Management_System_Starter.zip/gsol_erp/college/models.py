import uuid
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone
from .roles import ROLE_CHOICES

class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        abstract = True

class User(AbstractUser):
    role = models.CharField(max_length=32, choices=ROLE_CHOICES, default="STUDENT", db_index=True)
    phone = models.CharField(max_length=30, blank=True)
    must_change_password = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.get_full_name() or self.username} ({self.role})"

class Department(TimeStampedModel):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=160)
    is_active = models.BooleanField(default=True)
    def __str__(self): return f"{self.code} — {self.name}"

class Program(TimeStampedModel):
    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=180)
    department = models.ForeignKey(Department, on_delete=models.PROTECT, related_name="programs")
    award_title = models.CharField(max_length=120, blank=True)
    total_credits = models.PositiveIntegerField(default=0)
    duration_semesters = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    def __str__(self): return f"{self.code} — {self.name}"

class Applicant(TimeStampedModel):
    class Status(models.TextChoices):
        DRAFT="DRAFT","Draft"; SUBMITTED="SUBMITTED","Submitted"
        VERIFIED="VERIFIED","Documents verified"; REVIEW="REVIEW","Under review"
        ACCEPTED="ACCEPTED","Accepted"; WAITLIST="WAITLIST","Waitlisted"
        REJECTED="REJECTED","Rejected"; ENROLLED="ENROLLED","Enrolled"
    application_no = models.CharField(max_length=30, unique=True, default="")
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100, blank=True)
    email = models.EmailField()
    phone = models.CharField(max_length=30, blank=True)
    program = models.ForeignKey(Program, on_delete=models.PROTECT, related_name="applicants")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT, db_index=True)
    document_check_notes = models.TextField(blank=True)
    decision_notes = models.TextField(blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    def save(self, *args, **kwargs):
        if not self.application_no:
            self.application_no = f"APP-{uuid.uuid4().hex[:10].upper()}"
        super().save(*args, **kwargs)
    def __str__(self): return f"{self.application_no} — {self.first_name} {self.last_name}"

class Student(TimeStampedModel):
    class Status(models.TextChoices):
        ACTIVE="ACTIVE","Active"; SUSPENDED="SUSPENDED","Suspended"
        COMPLETED="COMPLETED","Completed"; GRADUATED="GRADUATED","Graduated"; WITHDRAWN="WITHDRAWN","Withdrawn"
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="student_profile", null=True, blank=True)
    student_id = models.CharField(max_length=30, unique=True, default="")
    applicant = models.OneToOneField(Applicant, on_delete=models.PROTECT, null=True, blank=True, related_name="student")
    program = models.ForeignKey(Program, on_delete=models.PROTECT, related_name="students")
    admission_date = models.DateField(default=timezone.localdate)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.ACTIVE, db_index=True)
    study_mode = models.CharField(max_length=20, choices=[("ONLINE","Online"),("PRINT","Print-based"),("CAMPUS","Campus")], default="ONLINE")
    date_of_birth = models.DateField(null=True, blank=True)
    address = models.TextField(blank=True)
    emergency_contact = models.CharField(max_length=100, blank=True)
    def save(self, *args, **kwargs):
        if not self.student_id:
            self.student_id = f"GSOL-{uuid.uuid4().hex[:8].upper()}"
        super().save(*args, **kwargs)
    def __str__(self): return self.student_id

class Semester(TimeStampedModel):
    name = models.CharField(max_length=80)
    year = models.PositiveSmallIntegerField()
    start_date = models.DateField()
    end_date = models.DateField()
    registration_open = models.BooleanField(default=False)
    class Meta:
        unique_together = [("name","year")]
        ordering = ["-year","name"]
    def __str__(self): return f"{self.name} {self.year}"

class Course(TimeStampedModel):
    code = models.CharField(max_length=30, unique=True)
    title = models.CharField(max_length=180)
    program = models.ForeignKey(Program, on_delete=models.PROTECT, related_name="courses")
    semester = models.ForeignKey(Semester, on_delete=models.PROTECT, related_name="courses")
    credits = models.PositiveSmallIntegerField(default=0)
    prerequisites = models.ManyToManyField("self", blank=True, symmetrical=False)
    moodle_course_id = models.CharField(max_length=80, blank=True)
    is_active = models.BooleanField(default=True)
    def __str__(self): return f"{self.code} — {self.title}"

class CourseRegistration(TimeStampedModel):
    class Status(models.TextChoices):
        REGISTERED="REGISTERED","Registered"; IN_PROGRESS="IN_PROGRESS","In progress"
        COMPLETED="COMPLETED","Completed"; WITHDRAWN="WITHDRAWN","Withdrawn"
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="course_registrations")
    course = models.ForeignKey(Course, on_delete=models.PROTECT, related_name="registrations")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.REGISTERED)
    registered_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["student","course"], name="unique_student_course")]
    def __str__(self): return f"{self.student} / {self.course}"

class AttendanceRecord(TimeStampedModel):
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="attendance")
    course = models.ForeignKey(Course, on_delete=models.PROTECT, related_name="attendance")
    date = models.DateField(default=timezone.localdate)
    present = models.BooleanField(default=False)
    recorded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    notes = models.CharField(max_length=255, blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["student","course","date"], name="unique_daily_attendance")]

class Assignment(TimeStampedModel):
    course = models.ForeignKey(Course, on_delete=models.PROTECT, related_name="assignments")
    title = models.CharField(max_length=180)
    instructions = models.TextField(blank=True)
    due_at = models.DateTimeField(null=True, blank=True)
    max_score = models.DecimalField(max_digits=7, decimal_places=2, default=100, validators=[MinValueValidator(0)])
    rubric = models.JSONField(default=dict, blank=True)
    moodle_assignment_id = models.CharField(max_length=80, blank=True)
    is_published = models.BooleanField(default=False)
    def __str__(self): return self.title

class Submission(TimeStampedModel):
    assignment = models.ForeignKey(Assignment, on_delete=models.PROTECT, related_name="submissions")
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="submissions")
    submitted_at = models.DateTimeField(default=timezone.now)
    text_response = models.TextField(blank=True)
    file = models.FileField(upload_to="submissions/%Y/%m/", blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["assignment","student"], name="unique_assignment_submission")]

class AssessmentResult(TimeStampedModel):
    class Status(models.TextChoices):
        DRAFT="DRAFT","Draft"; MARKED="MARKED","Marked"; MODERATED="MODERATED","Moderated"
        APPROVED="APPROVED","Approved"; PUBLISHED="PUBLISHED","Published"
    submission = models.OneToOneField(Submission, on_delete=models.PROTECT, related_name="result")
    marker = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="marked_results")
    score = models.DecimalField(max_digits=7, decimal_places=2, validators=[MinValueValidator(0)])
    feedback = models.TextField(blank=True)
    rubric_scores = models.JSONField(default=dict, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT, db_index=True)
    moderator = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name="moderated_results")
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name="approved_results")
    published_at = models.DateTimeField(null=True, blank=True)
    def __str__(self): return f"{self.submission} — {self.score}"

class MinistryPlan(TimeStampedModel):
    class Status(models.TextChoices):
        DRAFT="DRAFT","Draft"; SUBMITTED="SUBMITTED","Submitted"; APPROVED="APPROVED","Approved"; REJECTED="REJECTED","Rejected"; COMPLETED="COMPLETED","Completed"
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="ministry_plans")
    site_name = models.CharField(max_length=180)
    mentor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="mentored_plans")
    goals = models.TextField()
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT, db_index=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name="approved_ministry_plans")
    approved_at = models.DateTimeField(null=True, blank=True)

class MinistryLog(TimeStampedModel):
    plan = models.ForeignKey(MinistryPlan, on_delete=models.PROTECT, related_name="logs")
    date = models.DateField(default=timezone.localdate)
    hours = models.DecimalField(max_digits=5, decimal_places=2, validators=[MinValueValidator(0)])
    reflection = models.TextField()
    report_file = models.FileField(upload_to="ministry_reports/%Y/%m/", blank=True)
    mentor_reviewed = models.BooleanField(default=False)

class FeeInvoice(TimeStampedModel):
    class Status(models.TextChoices):
        OPEN="OPEN","Open"; PART_PAID="PART_PAID","Part paid"; PAID="PAID","Paid"; WAIVED="WAIVED","Waived"
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="invoices")
    invoice_no = models.CharField(max_length=40, unique=True, default="")
    description = models.CharField(max_length=180)
    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    amount_paid = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    due_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default="OPEN")
    def save(self, *args, **kwargs):
        if not self.invoice_no: self.invoice_no = f"INV-{uuid.uuid4().hex[:10].upper()}"
        if self.amount_paid >= self.amount: self.status = self.Status.PAID
        elif self.amount_paid > 0: self.status = self.Status.PART_PAID
        super().save(*args, **kwargs)

class LibraryLoan(TimeStampedModel):
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="library_loans")
    book_title = models.CharField(max_length=220)
    issued_at = models.DateField(default=timezone.localdate)
    due_date = models.DateField()
    returned_at = models.DateField(null=True, blank=True)
    fine_amount = models.DecimalField(max_digits=9, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    cleared = models.BooleanField(default=False)

class GraduationApplication(TimeStampedModel):
    class Status(models.TextChoices):
        SUBMITTED="SUBMITTED","Submitted"; AUDIT_PENDING="AUDIT_PENDING","Credit audit pending"
        AUDIT_FAILED="AUDIT_FAILED","Credit audit failed"; DUES_PENDING="DUES_PENDING","Dues pending"
        APPROVAL_PENDING="APPROVAL_PENDING","Approval pending"; APPROVED="APPROVED","Approved"
        LOCKED="LOCKED","Locked"; REJECTED="REJECTED","Rejected"
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="graduation_applications")
    requested_award = models.CharField(max_length=120)
    comprehensive_exam_passed = models.BooleanField(default=False)
    exit_interview_completed = models.BooleanField(default=False)
    credits_required = models.PositiveIntegerField(default=0)
    credits_earned = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=24, choices=Status.choices, default="SUBMITTED", db_index=True)
    audit_notes = models.TextField(blank=True)
    dues_cleared = models.BooleanField(default=False)
    registrar_approved = models.BooleanField(default=False)
    council_approved = models.BooleanField(default=False)
    locked_at = models.DateTimeField(null=True, blank=True)

class GraduationDocument(TimeStampedModel):
    class Kind(models.TextChoices):
        CERTIFICATE="CERTIFICATE","Certificate"; TRANSCRIPT="TRANSCRIPT","Transcript"
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="graduation_documents")
    kind = models.CharField(max_length=20, choices=Kind.choices)
    serial_number = models.CharField(max_length=80, unique=True, default="")
    verification_token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    issued_at = models.DateTimeField(default=timezone.now)
    revoked_at = models.DateTimeField(null=True, blank=True)
    def save(self, *args, **kwargs):
        if not self.serial_number: self.serial_number = f"GSOL-{self.kind[:3]}-{uuid.uuid4().hex[:10].upper()}"
        super().save(*args, **kwargs)

class AlumniProfile(TimeStampedModel):
    student = models.OneToOneField(Student, on_delete=models.PROTECT, related_name="alumni_profile")
    consent_to_contact = models.BooleanField(default=False)
    public_profile = models.BooleanField(default=False)
    current_role = models.CharField(max_length=180, blank=True)
    current_organization = models.CharField(max_length=180, blank=True)
    survey_opt_in = models.BooleanField(default=False)

class WorkflowGate(TimeStampedModel):
    class Stage(models.TextChoices):
        ADMISSION_REVIEW="ADMISSION_REVIEW","Admission review"
        OFFER_ACCEPTANCE="OFFER_ACCEPTANCE","Offer acceptance"
        MINISTRY_PLAN="MINISTRY_PLAN","Ministry plan approval"
        MINISTRY_COORDINATOR="MINISTRY_COORDINATOR","Ministry coordinator review"
        GRADE_APPROVAL="GRADE_APPROVAL","Grade approval"
        CREDIT_AUDIT="CREDIT_AUDIT","Credit audit"
        GRADUATION_APPROVAL="GRADUATION_APPROVAL","Graduation approval"
        GRADUATING_LIST="GRADUATING_LIST","Graduating list lock"
    class Status(models.TextChoices):
        PENDING="PENDING","Pending"; APPROVED="APPROVED","Approved"; REJECTED="REJECTED","Rejected"
    stage = models.CharField(max_length=40, choices=Stage.choices, db_index=True)
    object_type = models.CharField(max_length=80, help_text="Model name, e.g. graduationapplication")
    object_id = models.PositiveBigIntegerField()
    status = models.CharField(max_length=20, choices=Status.choices, default="PENDING", db_index=True)
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="requested_gates")
    decided_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name="decided_gates")
    decision_notes = models.TextField(blank=True)
    decided_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        indexes = [models.Index(fields=["object_type","object_id"]), models.Index(fields=["stage","status"])]

class AuditEvent(models.Model):
    occurred_at = models.DateTimeField(default=timezone.now, db_index=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    action = models.CharField(max_length=80, db_index=True)
    object_type = models.CharField(max_length=100, blank=True)
    object_id = models.CharField(max_length=80, blank=True)
    request_path = models.CharField(max_length=500, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    summary = models.TextField(blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    class Meta:
        ordering = ["-occurred_at"]
        indexes = [models.Index(fields=["actor","occurred_at"]), models.Index(fields=["object_type","object_id"])]

class Notification(TimeStampedModel):
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    title = models.CharField(max_length=180)
    message = models.TextField()
    read_at = models.DateTimeField(null=True, blank=True)
    link = models.CharField(max_length=500, blank=True)
