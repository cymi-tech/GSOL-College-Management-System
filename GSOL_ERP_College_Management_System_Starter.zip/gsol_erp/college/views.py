from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.http import JsonResponse, HttpResponseForbidden
from django.core.exceptions import ValidationError, PermissionDenied
from .models import Student, Applicant, Course, AssessmentResult, MinistryPlan, GraduationApplication, WorkflowGate, FeeInvoice
from .roles import has_capability
from .services import decide_gate

class LoginView(View):
    def get(self, request):
        return render(request, "registration/login.html", {"form": AuthenticationForm(request)})
    def post(self, request):
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect("dashboard")
        return render(request, "registration/login.html", {"form": form})

class LogoutView(View):
    def post(self, request):
        logout(request)
        return redirect("login")

@login_required
def dashboard(request):
    context = {
        "student_count": Student.objects.count(),
        "applicant_count": Applicant.objects.count(),
        "course_count": Course.objects.count(),
        "pending_gates": WorkflowGate.objects.filter(status="PENDING").count(),
        "pending_results": AssessmentResult.objects.exclude(status="PUBLISHED").count(),
        "ministry_plans": MinistryPlan.objects.count(),
        "graduation_pending": GraduationApplication.objects.exclude(status__in=["LOCKED","REJECTED"]).count(),
        "open_invoices": FeeInvoice.objects.exclude(status__in=["PAID","WAIVED"]).count(),
        "recent_gates": WorkflowGate.objects.select_related("requested_by","decided_by").order_by("-created_at")[:8],
        "can_decide": has_capability(request.user, "workflow.decide"),
    }
    return render(request, "dashboard.html", context)

@login_required
def workflow_decision(request, pk):
    if request.method != "POST":
        return redirect("dashboard")
    approve = request.POST.get("decision") == "approve"
    notes = request.POST.get("notes", "").strip()
    try:
        decide_gate(gate_id=pk, actor=request.user, approve=approve, notes=notes, request=request)
        messages.success(request, "Workflow decision recorded.")
    except (ValidationError, PermissionDenied) as exc:
        messages.error(request, str(exc))
        if isinstance(exc, PermissionDenied):
            return HttpResponseForbidden("You do not have permission to decide this gate.")
    return redirect("dashboard")

def health(request):
    return JsonResponse({"status": "ok", "service": "GSOL ERP"})
