from .models import AuditEvent

def record_event(*, actor=None, action, obj=None, request=None, summary="", metadata=None):
    ip = None
    path = ""
    if request is not None:
        forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
        ip = (forwarded.split(",")[0].strip() if forwarded else request.META.get("REMOTE_ADDR")) or None
        path = request.path[:500]
    return AuditEvent.objects.create(
        actor=actor if getattr(actor, "is_authenticated", False) else None,
        action=action,
        object_type=obj.__class__.__name__ if obj else "",
        object_id=str(obj.pk) if obj and obj.pk else "",
        request_path=path,
        ip_address=ip,
        summary=summary,
        metadata=metadata or {},
    )
