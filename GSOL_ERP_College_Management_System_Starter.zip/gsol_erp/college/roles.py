from django.core.exceptions import PermissionDenied

ROLE_CHOICES = [
    ("SUPER_ADMIN", "Super Admin"),
    ("COLLEGE_ADMIN", "College Admin"),
    ("REGISTRAR", "Registrar"),
    ("ADMISSIONS", "Admissions Officer"),
    ("ACADEMIC_COORDINATOR", "Academic Coordinator"),
    ("FACULTY", "Faculty"),
    ("EXAMINER", "Examiner"),
    ("MODERATOR", "Moderator"),
    ("MINISTRY_MENTOR", "Ministry Mentor"),
    ("MINISTRY_COORDINATOR", "Ministry Coordinator"),
    ("ACCOUNTANT", "Accountant"),
    ("LIBRARIAN", "Librarian"),
    ("HR_MANAGER", "HR Manager"),
    ("STUDENT", "Student"),
    ("PARENT", "Parent/Guardian"),
    ("ALUMNI_OFFICER", "Alumni Officer"),
]

# App-level capabilities. Django model permissions remain an additional layer.
ROLE_CAPABILITIES = {
    "SUPER_ADMIN": {"*"},
    "COLLEGE_ADMIN": {"dashboard.view", "admissions.manage", "academics.manage", "fees.manage", "reports.view", "workflow.decide"},
    "REGISTRAR": {"dashboard.view", "graduation.manage", "workflow.decide", "records.manage", "reports.view"},
    "ADMISSIONS": {"dashboard.view", "admissions.manage", "workflow.decide"},
    "ACADEMIC_COORDINATOR": {"dashboard.view", "academics.manage", "ministry.review", "workflow.decide", "reports.view"},
    "FACULTY": {"dashboard.view", "attendance.manage", "assessment.manage"},
    "EXAMINER": {"dashboard.view", "assessment.mark"},
    "MODERATOR": {"dashboard.view", "assessment.moderate"},
    "MINISTRY_MENTOR": {"dashboard.view", "ministry.evaluate"},
    "MINISTRY_COORDINATOR": {"dashboard.view", "ministry.review", "workflow.decide"},
    "ACCOUNTANT": {"dashboard.view", "fees.manage", "dues.clear"},
    "LIBRARIAN": {"dashboard.view", "library.manage", "dues.clear"},
    "HR_MANAGER": {"dashboard.view", "hr.manage"},
    "STUDENT": {"dashboard.view", "student.self"},
    "PARENT": {"dashboard.view", "student.authorized"},
    "ALUMNI_OFFICER": {"dashboard.view", "alumni.manage", "verification.manage"},
}

def has_capability(user, capability):
    if not user or not user.is_authenticated:
        return False
    if user.is_superuser or user.role == "SUPER_ADMIN":
        return True
    caps = ROLE_CAPABILITIES.get(user.role, set())
    return "*" in caps or capability in caps

def require_capability(user, capability):
    if not has_capability(user, capability):
        raise PermissionDenied(f"Your role cannot perform: {capability}")
