from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import (
    User, Department, Program, Applicant, Student, Semester, Course, CourseRegistration,
    AttendanceRecord, Assignment, Submission, AssessmentResult, MinistryPlan, MinistryLog,
    FeeInvoice, LibraryLoan, GraduationApplication, GraduationDocument, AlumniProfile,
    WorkflowGate, AuditEvent, Notification
)

@admin.register(User)
class GSOLUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (("GSOL profile", {"fields": ("role","phone","must_change_password")}),)
    add_fieldsets = UserAdmin.add_fieldsets + (("GSOL profile", {"fields": ("role","phone","must_change_password")}),)
    list_display = ("username","email","first_name","last_name","role","is_active")
    list_filter = ("role","is_active")

class ReadOnlyAuditAdmin(admin.ModelAdmin):
    list_display = ("occurred_at","actor","action","object_type","object_id","summary")
    list_filter = ("action","object_type","occurred_at")
    search_fields = ("summary","object_id","actor__username")
    readonly_fields = [f.name for f in AuditEvent._meta.fields]
    def has_add_permission(self, request): return False
    def has_change_permission(self, request, obj=None): return False
    def has_delete_permission(self, request, obj=None): return False

@admin.register(AuditEvent)
class AuditEventAdmin(ReadOnlyAuditAdmin): pass

@admin.register(WorkflowGate)
class WorkflowGateAdmin(admin.ModelAdmin):
    list_display = ("stage","object_type","object_id","status","requested_by","decided_by","created_at")
    list_filter = ("stage","status")
    readonly_fields = ("created_at","updated_at","decided_at")

for model in [
    Department, Program, Applicant, Student, Semester, Course, CourseRegistration,
    AttendanceRecord, Assignment, Submission, AssessmentResult, MinistryPlan, MinistryLog,
    FeeInvoice, LibraryLoan, GraduationApplication, GraduationDocument, AlumniProfile, Notification
]:
    admin.site.register(model)
