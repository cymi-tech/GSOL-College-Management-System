from django.test import TestCase
from django.core.exceptions import PermissionDenied
from django.contrib.auth import get_user_model
from college.roles import has_capability, require_capability
from college.models import Department, Program, Semester, Course, Applicant, WorkflowGate
from datetime import date

User = get_user_model()

class RoleCapabilityTests(TestCase):
    def test_student_cannot_decide_workflow(self):
        user = User.objects.create_user(username="student1", password="test-password-123", role="STUDENT")
        self.assertFalse(has_capability(user, "workflow.decide"))
        with self.assertRaises(PermissionDenied):
            require_capability(user, "workflow.decide")

    def test_super_admin_can_decide_workflow(self):
        user = User.objects.create_user(username="admin1", password="test-password-123", role="SUPER_ADMIN")
        self.assertTrue(has_capability(user, "workflow.decide"))

class AcademicModelTests(TestCase):
    def test_applicant_number_is_generated(self):
        department = Department.objects.create(code="THEO", name="Theology")
        program = Program.objects.create(code="BA-THEO", name="BA Theology", department=department)
        applicant = Applicant.objects.create(first_name="Test", email="test@example.com", program=program)
        self.assertTrue(applicant.application_no.startswith("APP-"))
