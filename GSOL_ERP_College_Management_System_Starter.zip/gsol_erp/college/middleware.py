from django.utils.deprecation import MiddlewareMixin
from .audit import record_event

class AuditRequestMiddleware(MiddlewareMixin):
    EXCLUDED = ("/static/", "/media/", "/health/")
    def process_response(self, request, response):
        if request.method in {"POST", "PUT", "PATCH", "DELETE"} and not request.path.startswith(self.EXCLUDED):
            # Never store request bodies, passwords, tokens, or form values in the audit log.
            try:
                record_event(
                    actor=getattr(request, "user", None),
                    action=f"HTTP_{request.method}",
                    request=request,
                    summary=f"Request completed with status {response.status_code}",
                    metadata={"status_code": response.status_code},
                )
            except Exception:
                # Auditing failures should be monitored; don't expose request data or break responses.
                pass
        return response
