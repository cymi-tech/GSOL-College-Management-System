from django.contrib.auth.signals import user_logged_in, user_login_failed, user_logged_out
from django.dispatch import receiver
from .audit import record_event

@receiver(user_logged_in)
def audit_login(sender, request, user, **kwargs):
    record_event(actor=user, action="LOGIN_SUCCESS", request=request, summary="User logged in")

@receiver(user_login_failed)
def audit_failed_login(sender, credentials, request, **kwargs):
    # Never log credentials or passwords.
    record_event(actor=None, action="LOGIN_FAILED", request=request, summary="Authentication failed")

@receiver(user_logged_out)
def audit_logout(sender, request, user, **kwargs):
    record_event(actor=user, action="LOGOUT", request=request, summary="User logged out")
