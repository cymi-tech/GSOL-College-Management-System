from django.core.exceptions import ValidationError, PermissionDenied
from django.db import transaction
from django.utils import timezone
from .audit import record_event
from .models import WorkflowGate, GraduationApplication, MinistryPlan, AssessmentResult
from .roles import require_capability

def decide_gate(*, gate_id, actor, approve, notes="", request=None):
    """Resolve an explicit approval gate; callers must be authenticated and authorized."""
    require_capability(actor, "workflow.decide")
    with transaction.atomic():
        gate = WorkflowGate.objects.select_for_update().get(pk=gate_id)
        if gate.status != WorkflowGate.Status.PENDING:
            raise ValidationError("This gate has already been decided.")
        gate.status = WorkflowGate.Status.APPROVED if approve else WorkflowGate.Status.REJECTED
        gate.decided_by = actor
        gate.decision_notes = notes
        gate.decided_at = timezone.now()
        gate.save(update_fields=["status","decided_by","decision_notes","decided_at","updated_at"])
        obj = _resolve_object(gate.object_type, gate.object_id)
        if approve:
            _apply_approved_gate(gate, obj, actor)
        else:
            _apply_rejected_gate(gate, obj)
        record_event(actor=actor, action="WORKFLOW_GATE_APPROVED" if approve else "WORKFLOW_GATE_REJECTED",
                     obj=obj, request=request, summary=f"{gate.stage}: {gate.status}", metadata={"gate_id": gate.pk, "notes": notes})
        return gate

def _resolve_object(object_type, object_id):
    model_map = {
        "graduationapplication": GraduationApplication,
        "ministryplan": MinistryPlan,
        "assessmentresult": AssessmentResult,
    }
    model = model_map.get(object_type.lower())
    if not model:
        raise ValidationError("Unsupported workflow object type.")
    try:
        return model.objects.select_for_update().get(pk=object_id)
    except model.DoesNotExist:
        raise ValidationError("Workflow target no longer exists.")

def _apply_approved_gate(gate, obj, actor):
    if isinstance(obj, MinistryPlan):
        if gate.stage == WorkflowGate.Stage.MINISTRY_PLAN:
            obj.status = MinistryPlan.Status.APPROVED
            obj.approved_by, obj.approved_at = actor, timezone.now()
            obj.save(update_fields=["status","approved_by","approved_at","updated_at"])
    elif isinstance(obj, AssessmentResult):
        if gate.stage == WorkflowGate.Stage.GRADE_APPROVAL:
            if obj.status not in {AssessmentResult.Status.MODERATED, AssessmentResult.Status.MARKED}:
                raise ValidationError("Only marked or moderated results can be approved.")
            obj.status, obj.approved_by = AssessmentResult.Status.APPROVED, actor
            obj.save(update_fields=["status","approved_by","updated_at"])
    elif isinstance(obj, GraduationApplication):
        if gate.stage == WorkflowGate.Stage.CREDIT_AUDIT:
            _run_credit_audit(obj)
        elif gate.stage == WorkflowGate.Stage.GRADUATION_APPROVAL:
            if not obj.dues_cleared:
                raise ValidationError("Dues must be cleared before graduation approval.")
            if obj.credits_earned < obj.credits_required:
                raise ValidationError("Credit requirement has not been met.")
            obj.registrar_approved = True
            obj.status = GraduationApplication.Status.APPROVAL_PENDING
            obj.save(update_fields=["registrar_approved","status","updated_at"])
        elif gate.stage == WorkflowGate.Stage.GRADUATING_LIST:
            if not (obj.registrar_approved and obj.council_approved and obj.dues_cleared):
                raise ValidationError("Registrar, council and dues clearance are required.")
            obj.status, obj.locked_at = GraduationApplication.Status.LOCKED, timezone.now()
            obj.save(update_fields=["status","locked_at","updated_at"])

def _apply_rejected_gate(gate, obj):
    if isinstance(obj, MinistryPlan):
        obj.status = MinistryPlan.Status.REJECTED
        obj.save(update_fields=["status","updated_at"])
    elif isinstance(obj, GraduationApplication):
        obj.status = GraduationApplication.Status.REJECTED
        obj.save(update_fields=["status","updated_at"])

def _run_credit_audit(application):
    blockers = []
    if application.credits_earned < application.credits_required:
        blockers.append(f"Credits: {application.credits_earned}/{application.credits_required}")
    if not application.comprehensive_exam_passed:
        blockers.append("Comprehensive examination not passed")
    if not application.exit_interview_completed:
        blockers.append("Exit interview not completed")
    if blockers:
        application.status = GraduationApplication.Status.AUDIT_FAILED
        application.audit_notes = "; ".join(blockers)
        application.save(update_fields=["status","audit_notes","updated_at"])
        raise ValidationError("Credit audit failed: " + application.audit_notes)
    application.status = GraduationApplication.Status.DUES_PENDING
    application.audit_notes = "Credit, comprehensive examination and exit interview requirements passed."
    application.save(update_fields=["status","audit_notes","updated_at"])

def create_gate(*, stage, obj, actor):
    require_capability(actor, "workflow.decide")
    return WorkflowGate.objects.create(
        stage=stage, object_type=obj.__class__.__name__.lower(), object_id=obj.pk, requested_by=actor
    )

def publish_result(*, result, actor, request=None):
    require_capability(actor, "assessment.manage")
    if result.status != AssessmentResult.Status.APPROVED:
        raise ValidationError("Only approved results can be published.")
    result.status = AssessmentResult.Status.PUBLISHED
    result.published_at = timezone.now()
    result.save(update_fields=["status","published_at","updated_at"])
    record_event(actor=actor, action="RESULT_PUBLISHED", obj=result, request=request, summary="Approved assessment result published")
    return result
