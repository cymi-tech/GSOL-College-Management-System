# GSOL ERP implementation roadmap

## Increment 1 — Foundation (this repository)
Django project, PostgreSQL settings, custom roles, core domain models, admin, dashboard, approval-gate service, audit trail, local setup.

## Increment 2 — Workflow completion
- Admission review and offer acceptance service transitions
- Student enrollment transaction, duplicate checks, fee ledger and payment reconciliation
- Prerequisite / credit-limit validation at course registration
- Attendance entry and course completion rules
- Marking, moderation, grade approval and result publication with separation of duties
- Ministry coordinator review, required hours and mentor mid-point/final evaluations
- Credit audit that reads course completions, fees, library loans and required milestones
- Registrar and council multi-step approval, immutable graduating-list snapshot

## Increment 3 — Moodle
Secure API client, user/course mapping, enrolment sync, assignment/grade sync, retry queue and sync audit.

## Increment 4 — Wider ERP
Library catalogue/stock, transport, hostel, HR/payroll, finance ledger, parent portal, notifications, analytics and exports.

## Increment 5 — Production readiness
Comprehensive automated tests, accessibility, backups/restore drill, monitoring, load testing, security review, cloud deployment and staff training.
